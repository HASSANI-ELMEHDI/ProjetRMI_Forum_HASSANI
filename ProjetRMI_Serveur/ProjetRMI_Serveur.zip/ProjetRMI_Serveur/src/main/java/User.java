public interface User {
    public void ecrire(String msg);
}
